import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;


class employeeinfo {
	int Id;
	String Name;
	String Addr;
	int salary;

	employeeinfo(int id, String name, String addr, int sal) {
		this.Id = id;
		this.Name = name;
		this.Addr = addr;
		this.salary = sal;
	}
}

public class employee{

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id : ");
		int eid = sc.nextInt();
		System.out.println("Enter employee name : ");
		String ename = sc.next();

		// Creating user-defined class objects
		employeeinfo e1 = new employeeinfo(1, "Pooja", "Bangalore", 48500);
		employeeinfo e2 = new employeeinfo(2, "Ram", "Mysore", 25000);
		employeeinfo e3 = new employeeinfo(10, "Hamsa", "Mumbai", 33000);
		
		ArrayList<employeeinfo> al = new ArrayList<employeeinfo>();
		al.add(e1);// adding Student class object
		al.add(e2);
		al.add(e3);

		Iterator itr = al.iterator();

		// traversing elements of ArrayList object

		employeeinfo emp;
		while (itr.hasNext()) {
			emp = (employeeinfo) itr.next();
			if (eid == emp.Id) {
				System.out.println("Employee Id : "+emp.Id); 
				System.out.println("Employee Name : "+emp.Name); 
				System.out.println("Employee Address : "+emp.Addr); 
				System.out.println("Salary : "+emp.salary);
			}
		}
		sc.close();

	}
}