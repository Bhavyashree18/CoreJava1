package live;

import music.playable;
import music.string.veena;
import music.wind.saxophone;

public class test {

	public static void main(String[] args) {
		veena veena = new veena();
		veena.play();
		
		//Instance for Saxophone class and calling Play method
		saxophone saxo = new saxophone();
		saxo.play();
		
		//Placing above instances in variable of type Playable and calling Play method
		playable p;
		p= new veena();
		System.out.println("Veena is playing : ");
		p.play();
		
		p = new saxophone();
		System.out.println("Saxophone is playing : ");
			
		}

}
