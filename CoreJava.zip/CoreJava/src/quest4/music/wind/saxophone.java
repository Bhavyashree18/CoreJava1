package music.wind;

import music.playable;

public class saxophone implements playable {

	public void play() {
		// TODO Auto-generated method stub
		
	}

}

