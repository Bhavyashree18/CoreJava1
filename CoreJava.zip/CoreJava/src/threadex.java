import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.Date;
//package javabasic;
class threadex extends Thread
{
   
public static void main (String[] args) {
        threadex t1=new threadex();
        Calendar c=Calendar.getInstance();
        System.out.println(t1.getName());
        t1.start();
        t1.setName("Mythread");
        System.out.println(t1.getName());
        System.out.println(new Date());
        try {
            Thread.sleep(10000);
             System.out.println(new Date());
            
        }
        catch(InterruptedException e)
        {
            System.out.println(e);
        }
       
    }
}
        


